from tutorial_interfaces.srv import Types
from tutorial_inter.srv import JV
import rclpy
import time
from math import sin,cos
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray
from sensor_msgs.msg import JointState
import numpy as np

class PD(Node):
    def __init__(self):
        super().__init__('give_ref') 

        self.subscription = self.create_subscription(
            JointState,
            '/joint_states',
            self.joint_callback,
            10
        )

        self.publisher=self.create_publisher(Float64MultiArray,'/forward_effort_controller/commands',10)
        timer_period = 0.1
        self.timer = self.create_timer(timer_period, self.timer_callback)

        self.f = open("values.txt","w")
        self.E = [0,0,0]
        self.N = [0,0,0]
        self.t = 0
        self.len = [2.05,0.9,1]
        self.q1 = 0
        self.q2 = 0
        self.q3 = 0
        self.a = 0
        self.b = 0
        self.c = 0
        self.e1 = 0
        self.e2 = 0
        self.e3 = 0
        self.e4 = 0
        self.e5 = 0
        self.e6 = 0
        self.J = [[0],[0]]
        self.U = [0,0,0]
        self.Edot = [0,0,0]
        self.output = Float64MultiArray()
        #rEE = []

        self.subscription

        self.srv = self.create_service(Types,'conv_ee',self.get_ee)
        self.srv = self.create_service(JV,'conv_jv',self.get_jv)

    def calc_p(self,position):

        self.q1 = position[0]
        self.q2 = position[1]
        self.q3 = position[2]

    def calc_v(self,velocity):
        self.v1 = velocity[0]
        self.v2 = velocity[1]
        self.v3 = velocity[2]


    def get_ee(self, request, response):
        self.a = request.a
        self.b = request.b
        self.c = request.c
        self.Vj = [self.a,self.b,self.c]

        self.J = ([

                    [-1*self.len[2]*sin(self.q1+self.q2) - self.len[1]*sin(self.q1), -1*self.len[2]*sin(self.q1+self.q2), 0],
                    [self.len[2]*cos(self.q1+self.q2) + self.len[1]*cos(self.q1),  self.len[2]*cos(self.q1+self.q2), 0],
                    [0,0,1],
                    [0,0,0],
                    [0,0,0],
                    [1,1,0]
                ])
        
        ende = np.matmul(self.J,np.transpose(self.Vj))
        response.ende1 = ende[0]
        response.ende2 = ende[1]
        response.ende3 = ende[2]
        response.ende4 = ende[3]
        response.ende5 = ende[4]
        response.ende6 = ende[5]
        
        return response

    def get_jv(self,request,response):
        self.e1 = request.e1
        self.e2 = request.e2
        self.e3 = request.e3
        self.e4 = request.e4
        self.e5 = request.e5
        self.e6 = request.e6
        self.E = [self.e1,self.e2,self.e3,self.e4,self.e5,self.e6]

        self.J = ([

                    [-1*self.len[2]*sin(self.q1+self.q2) - self.len[1]*sin(self.q1), -1*self.len[2]*sin(self.q1+self.q2), 0],
                    [self.len[2]*cos(self.q1+self.q2) + self.len[1]*cos(self.q1),  self.len[2]*cos(self.q1+self.q2), 0],
                    [0,0,1],
                    [0,0,0],
                    [0,0,0],
                    [1,1,0]
                ])

        joinv = np.matmul(np.linalg.pinv(self.J),np.transpose(self.E))
        response.j1=joinv[0]
        response.j2=joinv[1]
        response.j3=joinv[2]

        return response
        
    def timer_callback(self):
    
        # self.t = time.time()
        self.t1 = time.time()
        #self.t1 = 0.1

        self.E = [self.e1,self.e2,self.e3,self.e4,self.e5,self.e6]

        v1_c = self.v1
        v2_c = self.v2
        v3_c = self.v3

        self.J = ([

                    [-1*self.len[2]*sin(self.q1+self.q2) - self.len[1]*sin(self.q1), -1*self.len[2]*sin(self.q1+self.q2), 0],
                    [self.len[2]*cos(self.q1+self.q2) + self.len[1]*cos(self.q1),  self.len[2]*cos(self.q1+self.q2), 0],
                    [0,0,1],
                    [0,0,0],
                    [0,0,0],
                    [1,1,0]
                ])

        joinv = np.matmul(np.linalg.pinv(self.J),np.transpose(self.E))
        v1_d=joinv[0]
        v2_d=joinv[1]
        v3_d=joinv[2]

        self.E[0] = v1_d-v1_c
        self.E[1] = v2_d-v2_c
        self.E[2] = v3_d-v3_c

        self.kp = [15,20,20]
        self.kd = [0,0,0]

        for j in range(3):
            self.Edot[j] = (self.E[j] - self.N[j])/(self.t1-self.t)
            self.U[j] = (self.kp[j]*self.E[j]) + (self.kd[j]*self.Edot[j])

        

        self.f.write(str(self.t1)+'\t;'+str(v1_d)+'\t;'+str(v1_c)+ '\t;'+str(v2_d)+'\t;'+str(v2_c)+'\t;'+str(v3_d)+'\t;'+str(v3_c)+'\n')
        
        self.N = self.E
        self.t = self.t1
        self.output.data = [self.U[0],self.U[1],self.U[2]]

        self.publisher.publish(self.output)
    
    def joint_callback(self,msg):
        self.calc_p(msg.position)
        self.calc_v(msg.velocity)




        

def main(args=None):
    rclpy.init(args=args)

    pds = PD()
    rclpy.spin(pds)

    pds.destroy_node()

    rclpy.shutdown()

if __name__ == '__main__':
    main()