from tutorial_interfaces.srv import Types
import rclpy
from rclpy.node import Node
import time
from std_msgs.msg import Float64MultiArray
from sensor_msgs.msg import JointState


class PD(Node):
    def __init__(self):
        super().__init__('give_ref') 

        self.subscription = self.create_subscription(
            JointState,
            '/joint_states',
            self.joint_callback,
            10
        )

        self.subscription

        self.E = [0,0,0]
        self.N = [0,0,0]
        self.srv = self.create_service(Types,'conv_pd',self.get_pd)
        self.t = 0

        self.publisher=self.create_publisher(Float64MultiArray,'/forward_effort_controller/commands',10)
        timer_period = 0.1
        self.timer = self.create_timer(timer_period, self.timer_callback)

        self.U = [0,0,0]
        self.Edot = [0,0,0]

        self.q1 = 0
        self.q2 = 0
        self.q3 = 0
        self.a = 0
        self.b = 0
        self.c = 0
        self.output = Float64MultiArray()

    def calc_pd(self,position):

        self.q1 = position[0]
        self.q2 = position[1]
        self.q3 = position[2]

    def timer_callback(self):
        self.kd = [30,20,10]
        self.kp = [0.05,0.05,2]
        # self.t = time.time()
        self.t1 = time.time()
        #self.t1 = 0.1

        self.E[0] = self.a - self.q1
        self.E[1] = self.b - self.q2
        self.E[2] = self.c - self.q3

        for j in range(3):
            self.Edot[j] = (self.E[j] - self.N[j])/(self.t1-self.t)
            self.U[j] = (self.kp[j]*self.E[j]) + (self.kd[j]*self.Edot[j])

        

        f = open("values.txt","a")
        f.write(str(self.t1)+'\t;'+str(self.a)+'\t;'+str(self.q1)+ '\t;'+str(self.b)+'\t;'+str(self.q2)+'\t;'+str(self.c)+'\t;'+str(self.q3)+'\n')
        f.close()
       
        self.N = self.E
        self.t = self.t1
        self.output.data = [self.U[0],self.U[1],self.U[2]]

        self.publisher.publish(self.output)


    def get_pd(self, request, response):
        self.a = request.a
        self.b = request.b
        self.c = request.c

        response.z = 1.1
        return response

    def joint_callback(self,msg):
        self.calc_pd(msg.position)

        

def main(args=None):
    rclpy.init(args=args)

    pds = PD()
    rclpy.spin(pds)

    pds.destroy_node()

    rclpy.shutdown()

if __name__ == '__main__':
    main()
