import rclpy
from rclpy.node import Node
from numpy import cos, sin, deg2rad, rad2deg, pi
from scipy.spatial.transform import Rotation
import numpy as np
from sensor_msgs.msg import JointState
from geometry_msgs.msg import Pose 


class Forward (Node):
    def __init__(self):
        super().__init__('give_fk') 

        self.subscription = self.create_subscription(
            JointState,
            'joint_states',
            self.Fk_callback,
            10
        )

        self.subscription

        self.publisher=self.create_publisher(Pose,'topic',10)
        timer_period = 0.5
        self.timer = self.create_timer(timer_period, self.timer_callback)


        #linklengths
        self.l1 = 2.05
        self.l2 = 0.9
        self.l3 = 1
        self.pose = Pose()



    def timer_callback (self):
        self.publisher.publish(self.pose)
        

    def Fk_callback(self,msg):
        self.calc_fk(msg.position)

    
    #calculation fk


    def calc_fk(self,position):
        q1 = position[0]
        q2 = position[1] + pi
        q3 = position[2]


        A1=np.array([[cos(q1),-sin(q1),0, self.l1*cos(q1)],
             [sin(q1), cos(q2),0, self.l2*sin(q2)],
             [0,0,1,0],
             [0,0,0,1]])
        A2=np.array([[cos(q2),-sin(q2),0, -self.l2*cos(q2)],
             [sin(q2), -cos(q2),0, -self.l2*sin(q2)],
             [0,0,-1,0],
             [0,0,0,1]])

        A3=np.array([[1,0,0,0],
             [0,1,0,0],
             [0,0,1,q3],
             [0,0,0,1]])

        

        T2 = A1@A2
        T3 = T2@A3

        conv = Rotation.from_matrix(T3[:3,:3])

        quat = conv.as_quat()

        D= T3[:-1,3]


        self.pose.position.x = D[0]
        self.pose.position.y = D[1]
        self.pose.position.z = D[2]-1

        self.pose.orientation.x = quat[0]
        self.pose.orientation.y = quat[1]
        self.pose.orientation.z = quat[2]


def main(args=None):
    rclpy.init(args=args)

    frwds = Forward()
    rclpy.spin(frwds)


    frwds.destroy_node()

    rclpy.shutdown()

if __name__ == '__main__':
    main()


    



            

            




        
